#Unification

final_list1=[]
final_list2=[]
predicate1=input("Please input an Predicate 1 : ")
predicate2=input("Please input an Predicate 2 : ")
object_number=int(input("Enter the number of elements "))
e1=[]
e2=[]

for i in range (object_number):
  object=input("Enter the elements for predicate 1 : ")
  e1.append(object)

for i in range (object_number):
  people=input("Enter the elements for predicate 2 : ")
  e2.append(people)

def unify(predicate1, predicate2, e1, e2):
  final_list1=[predicate1]
  final_list1.append(e1)
  final_list2=[predicate2]
  final_list2.append(e2)

  print(final_list1)
  print(final_list2)
  
  if (predicate1==predicate2):
    for i in range(object_number):
      if e1[i] != e2[i]:
        print(f"{e1[i]} : {e2[i]}")
      else:
        pass
  else: print("Predicates are not equal")

    
unify(predicate1, predicate2, e1, e2)
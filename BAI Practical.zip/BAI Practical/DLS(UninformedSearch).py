

graph = {
    '5':['3','7'],
    '3':['2','4'],
    '7':['8'],
    '2':[],
    '4':['8'],
    '8':[]
}

visited = set() 

def DLS(visited,graph,node,depth_limit):
    if node not in visited and depth_limit >=0:
        print(node)
        visited.add(node)
        for neighbour in graph[node]:
            DLS(visited,graph,neighbour,depth_limit-1)

print('Depth Limited Search ')
depth_limit = 2
DLS(visited,graph,'5',depth_limit)


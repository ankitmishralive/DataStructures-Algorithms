# Constraint Satisfaction Problem

# Note : install before running
# !pip install python-constraint

from constraint import Problem

def color_graph(graph, colors):
    problem = Problem()
    nodes = list(graph.keys())

    for node in nodes:
        problem.addVariable(node, colors)

    for node, adjacents in graph.items():
        for adjacent in adjacents:
            problem.addConstraint(lambda x, y: x != y, (node, adjacent))

    solution = problem.getSolution()
    return solution

graph = {
    'A': ['B', 'C'],
    'B': ['A', 'C', 'D'],
    'C': ['A', 'B', 'D', 'E'],
    'D': ['B', 'C', 'E', 'F'],
    'E': ['C', 'D', 'F'],
    'F': ['D', 'E'],
}

colors = ['red', 'green', 'blue']

solution = color_graph(graph, colors)
print(solution)
# Genetic Algorithm

import random

def fitness_function(x):
    return x + 2

population_size = 1000
genome_length = 18
num_generations = 5
mutation_rate = 0.25

population = []
for i in range(population_size):
    genome = [random.randint(0, 1) for i in range(genome_length)]
    population.append(genome)

for generation in range(num_generations):
    fitness_scores = [fitness_function(int(''.join(map(str, genome)), 2)) for genome in population]

    parents = []
    for i in range(population_size):
        parent1 = population[random.randint(0, population_size - 1)]
        parent2 = population[random.randint(0, population_size - 1)]
        if fitness_scores[population.index(parent1)] < fitness_scores[population.index(parent2)]:
            parents.append(parent1)
        else:
            parents.append(parent2)

    offspring = []
    for i in range(population_size):
        parent1 = parents[random.randint(0, population_size - 1)]
        parent2 = parents[random.randint(0, population_size - 1)]
        crossover_point = random.randint(0, genome_length - 1)
        child = parent1[:crossover_point] + parent2[crossover_point:]
        for j in range(genome_length):
            if random.random() < mutation_rate:
                child[j] = 1 - child[j]
        offspring.append(child)
    population = offspring

    fittest_index = fitness_scores.index(min(fitness_scores))
    fittest_genome = population[fittest_index]
    fittest_individual = int(''.join(map(str, fittest_genome)), 2)
    print("Generation:", generation, "Fittest individual:", fittest_individual, "Fitness score:", fitness_scores[fittest_index])


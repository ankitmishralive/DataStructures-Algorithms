# Decision Tree

import pandas as pd
from math import log2

data = { 
    'Outlook': ['sunny', 'sunny', 'overcast', 'rainy', 'rainy', 'rainy', 'overcast', 'sunny', 'sunny', 'rainy'], 
    'Temperature': ['hot', 'hot', 'hot', 'mild', 'cool', 'cool', 'cool', 'mild', 'cool', 'mild'], 
    'PlayTennis': ['no', 'no', 'yes', 'yes', 'yes', 'no', 'yes', 'no', 'yes', 'yes']
}
df = pd.DataFrame(data)
df.head()

def entropy (examples):
    num_examples =  len(examples)
    num_positive = sum(examples [ 'PlayTennis']=='yes')
    num_negative = sum(examples[ 'PlayTennis'] == 'no')
    if num_positive == 0 or num_negative == 0: return 0
    p_positive = num_positive /num_examples
    p_negative = num_negative /num_examples
    return -p_positive*log2(p_positive) -p_negative*log2 (p_negative)

def information_gain(feature, examples):
    feature_values =examples[feature].unique()
    num_examples = len(examples)
    current_entropy = entropy(examples)
    new_entropy = 0
    for value in feature_values:
        subset = examples[examples[feature] == value]
        new_entropy+=len(subset) / num_examples* entropy (subset)
    return current_entropy - new_entropy

def build_decision_tree (examples, features):
    if len(examples[ 'PlayTennis'].unique()) == 1:
        return examples[ 'PlayTennis'].iloc[0]
    if len(features) == 0:
        return examples[ 'PlayTennis'].value_counts().idxmax()
    information_gains = {feature: information_gain (feature, examples) for feature in features}
    best_feature = max(information_gains, key=information_gains.get)
    tree = {best_feature: {}}
    remaining_features = [feature for feature in features if feature != best_feature]
    for value in examples [best_feature].unique():
        subset = examples [examples [best_feature] == value]
        if len(subset) == 0:
            tree[best_feature][value] = examples[ 'PlayTennis'].value_counts().idxmax()
        else:
            tree[best_feature][value] = build_decision_tree (subset, remaining_features)
    return tree

features = ['Outlook', 'Temperature']
decision_tree = build_decision_tree (df, features)
print(decision_tree)